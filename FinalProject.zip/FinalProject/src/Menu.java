public class Menu
{
  
  public Menu()
  {
    menu();
  }
  
  /*
   * dictates the methods necessary to call and follows decisions of user
   */
  public void menu()
  {}
  
}