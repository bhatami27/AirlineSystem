public class Date
{
  private int month; //the month 
  private int day; // the day
  private int year; // the year
  
  /* CONSTRUCTOR
   * @param d day 
   * @param m month 
   * @param y year
   */
  public Date(int d, int m, int y)
  {
    this.month = m;
    day = d;
    year = y;
  }
  
  /*
   * The getter for the month
   * @return month represents the month
   */
  public int getMonth()
  {return month;}
  
  /*
   * The Setter for the month
   * @param m Sets the instance variable, month, to be equal to the parameter
   */
  public void setMonth(int m)
  {}
  
  /*
   * The Getter for day
   * @return day represents the day
   */
  public int getDay()
  {return day;}
  
  /*
   * The setter for the day
   * @param d Sets the instance variable, day, to be equal to the parameter
   */
  public void setDay(int d)
  {}
  
  /*
   * The getter for the year
   * @return year represents the year
   */
  public int getYear()
  {return year;}
  
  /*
   * The setter for year
   * @param y Sets the instance variable, year, to be equal to the parameter
   */
  public void setYear(int y)
  {}
  
  /*
   * @return String the Date represented in numbers
   */
  public String toString()
  {return "";}
  
  
  
}