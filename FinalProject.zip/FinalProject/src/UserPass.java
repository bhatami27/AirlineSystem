import java.util.Scanner;
public class UserPass
{
    public static void main(String[] args)
    {
        String username, password;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter username:");//username:user
        username = s.nextLine();
        System.out.print("Enter password:");//password:user
        password = s.nextLine();
        if(username.equals("username") && password.equals("password"))
        {
            Scanner myChoice = new Scanner(System.in);
            Scanner myInt = new Scanner(System.in);
            boolean exitThis = true;
            while(exitThis == true) {
                System.out.println("Menu:");
                System.out.println("A : Book a Trip!: ");
                System.out.println("E : Logout  ");
                String choice = myChoice.nextLine();
                switch(choice)
                {
                    ////////////////////////////////////////////////////////
                    //A
                    case "A":
                        System.out.println("Input size");
                        int numA = myInt.nextInt();
                        break;
                    ////////////////////////////////////////////////////////
                    //Exit
                    case "E":
                        exitThis = false;
                        break;
                    default :
                        System.out.println("Incorrect, re-try.");
                }
            }
            myChoice.close();
            myInt.close();
            }
        if(username.equals(username) && password.equals(password))
        {
            System.out.println("Authentication Successful");
        }
        else
        {
            System.out.println("Authentication Failed");
        }
    }
}