import java.util.ArrayList;

public final class AirLineSystem
{
    private static ArrayList<Customer> Customers; //list of Customers in the system
    private static ArrayList<Flight> allFlights; // list of Flight in the system
    private static ArrayList<Airline> Airlines; //list of Airline in the system
    private static int totalFlightsLent;

    public AirlineSystem()
    {
        totalFlightsLent = 0;
    }

    /*
     * The Customer that's given that will be added to the system, in the ArrayList of Customers
     * @param st The Customer that will be added to the system, in the ArrayList of Customers
     */
    public static void addCustomer(Customer st)
    {}

    /*
     * The Customer that will be deleted from the system, in the ArrayList of Customers
     * @param The Customer that will be deleted fron the system, in the ArrayList of Customers
     */
    public static void deleteCustomer(Customer st)
    {}

    /*
     * Sorts the Flights in the ArrayList<Flight> of the titles
     */
    public static void sortFlights() //sorts Flights.
    {}

    /*
     * Getter for allFlights
     * @return allFlights Returns the ArrayList<Flight> that is in the Library System
     */
    public static ArrayList<Flight> getFlights()
    {return allFlights;}

    /*
     * Getter for Customers
     * @return Customers Returns the ArrayList<Customer> that is in the Library System
     */
    public static ArrayList<Customer> getCustomers()
    {return Customers;}

    /*
     * Adds given Airline to th system
     * @param lb Adds the given Airline to the system
     */
    public static void addAirline(Airline lb)
    {}

    /*
     * Deletes given Airline from th system
     * @param lb Deletes the given Airline from the system
     */
    public static void deleteAirline(Airline lb)
    {}

    /*
     * When a Flight is checkout to a Studuent, it increments the totalFlightsLent by one.
     * Represents the Unique ID that is tied to the checked out Flight
     */
    public static void incrementFlightsCheckedout() //totalFlightsLent++
    {}

    /*
     * Searchs Flight.title in ArrayList<Flight> and outputs
     * @param title Searchs a Flight.title from ArrayList<Flight> and outputs it
     */
    public static void searchTitle(String title)
    {}

    /*
     * Searchs Flight.LocationName in ArrayList<Flight> and outputs it
     * @param LocationName Searchs a Flight.LocationName from ArrayList<Flight> and outputs it
     */
    public static void searchLocation(String Location)
    {}

    /*
     * Searchs Flight.numDate in ArrayList<Flight> and outputs it
     * @param Date Searchs a Flight.numDate from ArrayList<Flight> and outputs it
     */
    public static void searchDate(int Date)
    {}

}