public class Airline
{
    private String name; //name of the Airline
    private String username; // username of the Airline
    private String password; //password of the Airline


    /* CONSTRUCTOR
     * @param nam Name of the Airline
     * @param userNam Username of the Airline
     * @param pass Password of the Airline
     */
    public Airline(String nam, String userNam, String pass)
    {
        this.name = nam;
        this.username = userNam;
        this.password = pass;
    }

    /*
     * The getter for name
     * @return name The name of the Airline
     */
    public String getName()
    {return name;}

    /*
     * The setter for name
     * @param n Sets the instance variable, name, equal to the parameter.
     */
    public void setName(String n)
    {}

    /*
     * The getter for username
     * @return username Returns the username of the Airline
     */
    public String getUserName()
    {return username;}

    /*
     * The setter for the username
     * @param name Sets the the instance variable, username, equal to the parameter
     */
    public void setUserName(String name)
    {}

    /*
     * The getter for password
     * @return password Returns the password for the Airline
     */
    public String getPassword()
    {return password;}

    /*
     * The setter for the password
     * @param pass Sets the instance variable, password, equal to the parameter
     */
    public void setPassword(String pass)
    {}

    /*
     * Airlines have the power to change the amount of Flight fees's in any given Customer account
     * @param st The Customer  passed will have their Flight fee changed in accordance to the parameter, num
     * @param num The amount that the Customer's Flight fee wil change
     */
    public void setFlightFee(Customer st, int num)
    {}

    /*
     * Adds given Flight the the ArrayList<Flight> in the Airline System
     * @param bk Adds the given Flight to the ArrayList<Flight>, in the Airline System
     */
    public void addFlight(Flight fl)
    {}

    /*
     * Deletes given Flight from the ArrayList<Flight>, in the Airline System
     * @param bk Deletes given Flight from the ArrayList<Flight>, in the Airline System
     */
    public void deleteFlight(Flight fl)
    {}

    /*
     * Outputs the list of checkout Flight's
     */
    public void getCheckedFlights()
    {}

}