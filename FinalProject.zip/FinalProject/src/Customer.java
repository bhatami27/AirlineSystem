import java.util.ArrayList;

public class Customer
{
    private String name; //name of the Name
    private String userName; // name of the userName
    private String password; // name of the password
    private ArrayList<Flight> checkFlight; //list of the Flights that Customer has checked out
    private Boolean FightBooked; //true = booked | false = not booked
    private int FlightFee; //represents the amount of flight fees that the Customer has


    /* CONSTRUCTOR
     * @param name name of the Customer
     * @param userN the username of the Customer
     * @param pass the password of the Customer
     */
    public Customer(String name, String userN, String pass)
    {
        this.name = name;
        this.userName = userN;
        this.password = pass;
        checkFlight = new ArrayList<Flight>();
        FightBooked = false;
        FlightFee = 0;
    }


    /*
     * Getter for the name of the Customer
     * @return name Returns the name of the Customer
     */
    public String getName()
    {return name;}

    /*
     * Setter for the name
     * @param n Sets the instance variable, name, to be equal to the parameter
     */
    public void setName(String n)
    {}

    /*
     * Getter for the Customer
     * @return userName returns the userName of the Customer
     */
    public String getUserName()
    {return userName;}

    /*
     * Setter for the username
     * @param name Sets the instance variable, name, to be equal to the parameter
     */
    public void setUserName(String name)
    {}

    /*
     * Getter for the password of the Customer
     * @return password returns the password of the Customer
     */
    public String getPassword()
    {return password;}

    /*
     * Getter for the password of the Customer
     * @param pass Sets the instance variable, password, equal to the parameter
     */
    public void setPassword(String pass)
    {}

    /*
     * Represents the checked out Flights that the Customer currently has.
     * @param fl Adds the Flight the ArrayList<Flight>, checkFlight
     */
    public void bookFlight(Flight fl)
    {}

    /*
     * Represents the Customer turn in the given Flight
     * @param fl Deletes the given Flight from the ArrayList<Flight>, checkFlight
     */
    public void cancelFlight(Flight fl)
    {}

    /*
     * Setter for FightBooked
     * @param bool Sets the instance variable, FightBooked, to be equal to the parameter
     */
    public void getFlightFee(Boolean bool)
    {}

    /*
     * Getter for getFlightFee
     * @return getFlightFee Returns the getFlightFee of the Customer
     */
    public boolean setFlightFee()
    {}

    /*
     * Getter for FlightFee
     * represents the amount of FlightFee fees that Customer has
     * @return FlightFee Returns the FlightFee in the Customer
     */
    public int equals(Customer)
    {}


    /*
     * Setter for FlightFee
     * @param num Sets the instance variable, FlightFee, to be equal to the parameter
     */
    public void setFlightFee(int num)
    {}
}