public class BookTrip
{
    private String customerNames; //name of the customerName
    private int RoundPrice;//represents the price of round trip
    private int singlePrice;//represents the price of one way
    private int childPrice;//represents the child price
    private Boolean availableFlight; //true means its available, otherwise not
    private Date dateF; //represents the date to be turned in
    private int food; //unique number for being checked out

    /* CONSTRUCTOR
     * @param customerName name of the customerName
     * @param price the price number of the Book
     * @param Class the Class of the Book
     */
    public BookTrip(String customerName, int price, String Class)
    {
        this.food = customerName;
        this.RoundPrice = price;
        this.Class = Class;
        availableFlight = true;
    }

    /*
     * The getter for the name of the customerName
     * @return food the name of the customerName
     */
    public String getcustomerNames()
    {return food;}

    /*
     * Setter for the customerNames name
     * @param name sets the customerName's name of the parameter
     */
    public void setcustomerNames(String name)
    {}

    /*
     * A getter for the price number
     * @return RoundPrice the price number of the book
     */
    public int getprice()
    {return RoundPrice;}

    /*
     * The setter for RoundPrice
     * @param num Sets the instance variable, RoundPrice, to the parameter num
     */
    public void setprice(int num)
    {}

    /*
     * the getter for the Class of the book
     * @return Class The book Class
     */
    public String getClass()
    {return Class;}

    /*
     * Setter for the book Class
     * @param Class Sets the instance variable, Class, to be equal of the parameter
     */
    public void setClass(String Class)
    {}

    /*
     * The getter for availableFlight
     * @return availableFlight
     */
    public Boolean getavailableFlight()
    {return availableFlight;}

    /*
     * The setter for availableFlight
     * @param stat Sets the instance variable, availableFlight, to be equal of stat
     */
    public void setavailableFlight(Boolean stat)
    {}

    /*
     * The getter of the dateF of the Book
     * @return dateF Returns the Date of the Book
     */
    public Date getDate()
    {return dateF;}

    /*
     * The setter for dateF
     * @param dt Sets the instance variable, dateF, to be equal to the parameter
     */
    public void setDate(Date dt)
    {}

    /*
     * The getter for the date
     * @return date returns the date of the flight.
     */
    public int getfood()
    {return food;}

    /*
     * The setter for the food
     * @param num Sets the instance variable, food, to be equal to the parameter
     */
    public void setfood(int num) //set food choice
    {}

}