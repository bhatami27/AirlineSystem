public class Payment {

    private int ccNumber; //credit card number of customer

    public Payment{
        /*
         *allows user to choose payment method cc or points
         */
    }
    public void creditCard(int ccNumber){
        return ccNumber;
        /*
         *gets cc number from customer and then ends payment
         */
    }
    public void flightPoints(boolean){
        return true;
        /*
         *instantly ends payment because points were used
         */
    }
}
